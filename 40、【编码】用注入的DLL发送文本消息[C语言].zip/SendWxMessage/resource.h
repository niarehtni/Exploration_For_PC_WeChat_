//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define ID_SELF                         2
#define ID_HELP                         3
#define ID_QQ                           4
#define ID_RESTART                      5
#define IDD_MAIN                        101
#define IDC_WXID                        1001
#define IDC_WXMSG                       1002
#define ID_SEND                         1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
